package pozole;

/**
 *
 * @author 
 */
public class Pozole 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Tablero t =new Tablero();
        t.setVisible(true);
    }        
}
